'''
외부망 Pass C
'''

# settings.py
MAIL_HOST = "172.16.100.53"
MAIL_PORT = "1521"
MAIL_SID = "orcl"
MAIL_USER = "c##coraise"
MAIL_PW = "dev123"
MAIL_TABLE = "BOK_MAIL"


# lib.py
def insert_mail_data(html, recipient_info, subject):
    app.logger.info("Mail DB Start")
    error_word = ""

    host = settings.MAIL_HOST
    port = settings.MAIL_PORT
    sid = settings.MAIL_SID
    user = settings.MAIL_USER
    password = settings.MAIL_PW
    table_name = settings.MAIL_TABLE
    try:
        dsn = cx.makedsn(host, port, sid)
        result = cx.connect(user, password, dsn)

    except Exception as e:
        app.logger.info(e)
        error_word = str(e)

        if "ORA-12170" in error_word:
            error_word = "timed out"
        elif "ORA-12545" in error_word:
            error_word = "connect fail"
        elif "ORA-12505" in error_word:
            error_word = "sid"
        elif "ORA-01017" in error_word:
            error_word = "id/pw"
        
        app.logger.info(error_word)

    insert_query = f"INSERT INTO {table_name} (SEQ, MSG_CODE, TO_ID, TO_NAME, TO_EMAIL, FROM_NAME, FROM_EMAIL, TARGET_DATE, REG_DATE, SUBJECT, MAP_CONTENT) VALUES (my_seq.nextval, :1, :2, :3, :4, :5, :6, :7, :8, :9, :10)"

    sysdate = datetime.now()
    to_id = recipient_info['to_id']
    to_name = recipient_info['to_name']
    to_email = recipient_info['to_email']
    subject = subject

    try:
        cur = result.cursor()
        cur.execute(insert_query, ['AD01', to_id, to_name, to_email, 'AD시스템', 'aduser-info@bok.or.kr', sysdate, sysdate, subject, html])
        result.commit()

        cur.close()
        result.close()

    except Exception as e:
        app.logger.info(e)

    app.logger.info("Mail DB End")



def get_recipient_info(users):
    recipient_info = {
        "to_id": "",
        "to_name": "",
        "to_email": "",
    }

    attributes = ["mail", "displayName", "employeeNumber"]
    for employee_number in users:
        criteria = f"(&(objectClass=user)(employeeNumber={employee_number}))"
        result = get_ad_results(criteria, attributes)

        if result:
            result = result[0]
            for k, v in result.items():
                if k == 'displayName':
                    recipient_info['to_name'] += f"{v[0].decode()};"
                elif k == 'employeeNumber':
                    recipient_info['to_id'] += f"{v[0].decode()};"
                else:
                    recipient_info['to_email'] += f"{v[0].decode()};"
    
    return recipient_info


def image_to_base64_str(image_path):
    with open(image_path, "rb") as image:
        base64_image = base64.b64encode(image.read())
    base64_image = str(base64_image).split("'")[1]
    return base64_image



# user.py user_auth
@core_bp.route("/user_auth", methods=["POST"])
def user_auth():
    data = request.form

    auth_type = data["auth_type"]

    if auth_type == "Mail":
        user_id = data["user_id"]
        user_email = data["user_email"]

        action = 'Verification 버튼 클릭'
        description = f'인증방식: {auth_type} / id: {user_id} / mail: {user_email}'
        if session:
            create_audit_log(action, description)
        else:
            create_audit_log(action, description, username='anonymous')

    else:
        user_id = data["user_id"]

        action = "Verification 버튼 클릭"
        description = f"인증방식: {auth_type} / id: {user_id}"
        if session:
            create_audit_log(action, description)
        else:
            create_audit_log(action, description, username="anonymous")

    ldap_data = get_ldap_info()

    # LDAP INFO
    if ldap_data is not None:
        mail_attr = ldap_data["mail_attr"]
        otp_attr = ldap_data["otp_attr"]
    else:
        return make_response("none_ldap_info", 400)
        # return jsonify('none_ldap_info')

    # AD userParameters 속성사용. otp_attr 값이 있다면 해당 값의 속성사용.
    if otp_attr == "":
        otp_attr = "userParameters"
    
    # 추가한 코드
    if mail_attr == "":
        mail_attr = "mail"

    criteria = f"(&(objectClass=user)(sAMAccountType=805306368)(sAMAccountName={user_id}))"
    # attributes = ["objectClass", otp_attr, "mail"]

    attributes = ["objectClass", otp_attr, mail_attr, "employeeNumber", "displayName"]  # 외부망
    ldap_results = get_ad_results(criteria, attributes)

    if not ldap_results:
        # return jsonify('none_user')
        return make_response("none_user", 400)

    ad_user = ldap_results[0]

    chk_valid_user = False

    # AD의 objectClass 속성의 값이 'user'(사용자)인지 확인.
    for object_class in ad_user["objectClass"]:

        if object_class.decode() == "user":
            chk_valid_user = True

    if chk_valid_user == False:
        # return jsonify('not_user')
        return make_response("not_user", 400)

    if auth_type == "Mail":

        # AD mail 속성에 값이 없다면 'none_email' 리턴.
        if ad_user.get("mail") is not None:
            # user_info 테이블 mail 컬럼의 값이 없다면 기본값을 mail 속성으로.

            if mail_attr == "" or mail_attr == "None" or mail_attr is None:
                mail_attr = "mail"

            email = ad_user[mail_attr][0].decode()
        else:
            # return jsonify('none_email')
            return make_response("none_email", 400)

        # 입력받은 email과 AD의 email이 맞는지 확인.
        if email == user_email:
            otp_data = db.session.query(Otp).filter(Otp.email == user_email).first()

            if otp_data is not None:

                current = datetime.now()
                minutes_later = otp_data.updated_at + timedelta(minutes=2)

                if minutes_later < current:

                    action = "Verification 버튼 클릭"
                    description = f"인증방식: {auth_type} / id: {user_id} / mail: {user_email}"
                    if session:
                        create_audit_log(action, description)
                    else:
                        create_audit_log(action, description, username="anonymous")

                else:
                    # return jsonify(['time_later',str(otp_data.updated_at)])
                    return make_response({"last_updated": otp_data.updated_at}, 403)
            else:

                action = "Verification 버튼 클릭"
                description = f"인증방식: {auth_type} / id: {user_id} / mail: {user_email}"
                if session:
                    create_audit_log(action, description)
                else:
                    create_audit_log(action, description, username="anonymous")

            # ranStr = send_email(user_id, user_email)
            ranStr = send_email(user_id, ad_user, mail_attr)  # 내부망

            if ranStr == "send_fail":
                return jsonify(["matching", ranStr])
            else:
                return jsonify(["matching", ""])

        else:
            # return jsonify('not_matched_email')
            return make_response("not_matched_email", 400)
    else:
        # Otp_account에 등록된 사용자인지 확인.
        chk_account = otp_account_check(ad_user, otp_attr)

        if chk_account:
            return jsonify(["matching", "app_otp"])
        else:
            return jsonify("no_app_otp")



# user.py send_email
def send_email(user_id, ad_user, mail_attr):
    user_email = ad_user[mail_attr][0].decode()  # 추가한 코드

    smtp_data = Smtp_info.query.first()
    mail_form = Mail_form.query.filter(Mail_form.type == "otp_mail").first()

    if smtp_data is not None:
        current_app.config["MAIL_SERVER"] = smtp_data.mail_server

        if smtp_data.mail_port != "":
            current_app.config["MAIL_PORT"] = int(smtp_data.mail_port)

        if smtp_data.use_tls == "tls":
            current_app.config["MAIL_USE_TLS"] = True
            current_app.config["MAIL_USE_SSL"] = False

        elif smtp_data.use_tls == "ssl":
            current_app.config["MAIL_USE_TLS"] = False
            current_app.config["MAIL_USE_SSL"] = True

        else:
            current_app.config["MAIL_USE_TLS"] = False
            current_app.config["MAIL_USE_SSL"] = False

        if smtp_data.user_relay == "idpw":
            current_app.config["MAIL_USERNAME"] = smtp_data.mail_username
            current_app.config["MAIL_PASSWORD"] = smtp_data.mail_password

        current_app.config["MAIL_DEBUG"] = False

        try:
            mail_title = smtp_data.title_text
            # mail_content = smtp_data.content_text
            sender_email = smtp_data.sender
            mail = Mail(current_app)
        except Exception as e:
            current_app.logger.info("ID : %s, Email : %s - SMTP ERROR : %s" % (user_id, user_email, e))
    try:
        msg = Message(mail_title, sender=sender_email, recipients=[user_email])
        ranStr = ""

        for i in range(6):
            ranStr = ranStr + str(random.randrange(0, 10))

        if mail_form is None:
            msg.attach(
                "passc_logo.png",
                "image/png",
                open("adpass/templates/images/passc_logo.png", "rb").read(),
                "inline",
                headers=[
                    ["Content-ID", "<logo>"],
                ],
            )
            msg.html = render_template("mail_pc.html", user_id=user_id, ranStr=ranStr)
            logo = "adpass/templates/images/passc_logo.png"
            base64_logo = image_to_base64_str(logo)
            html = render_template("mail_pc.html", user_id=user_id, ranStr=ranStr, logo=base64_logo)
        else:
            if mail_form.logo is None:
                msg.attach(
                    "passc_logo.png",
                    "image/png",
                    open("adpass/templates/images/passc_logo.png", "rb").read(),
                    "inline",
                    headers=[
                        ["Content-ID", "<logo>"],
                    ],
                )
                logo = "adpass/templates/images/passc_logo.png"
                base64_logo = image_to_base64_str(logo)
            else:
                msg.attach(
                    "passc_logo.png",
                    "image/png",
                    open("adpass/static/mail_logo/" + str(mail_form.logo), "rb").read(),
                    "inline",
                    headers=[
                        ["Content-ID", "<logo>"],
                    ],
                )
                logo = "adpass/static/mail_logo/" + str(mail_form.logo)
                base64_logo = image_to_base64_str(logo)
            msg.html = render_template(
                "custom_mail_pc.html",
                user_id=user_id,
                ranStr=ranStr,
                explanation=mail_form.explanation,
            )
            html = render_template("custom_mail_pc.html", user_id=user_id, ranStr=ranStr, logo=base64_logo)
        # mail.send(msg)
        '''
        외부망
        '''
        recipient_info = {
            'to_id': ad_user['employeeNumber'][0].decode(),
            'to_name': ad_user['displayName'][0].decode(),
            'to_email': user_email
        }
        subject = "[한국은행] 외부망 Pass Changer - otp 번호"
        insert_mail_data(html, recipient_info, subject)

        # OTP DB에 넣기 사용자의 email이 있다면 = update. 없다면 = insert.
        otp_data = db.session.query(Otp).filter(Otp.email == user_email).first()

        if otp_data is not None:
            otp_data.otp_num = ranStr
            db.session.commit()
        else:
            otp_data = {}
            otp_data["email"] = user_email
            otp_data["otp_num"] = ranStr
            otp = Otp(**otp_data)
            db.session.add(otp)
            db.session.commit()

        current_app.logger.info("ID : %s, Email : %s - OTP Send Success" % (user_id, user_email))
        return ranStr
    except Exception as e:
        current_app.logger.info("ID : %s, Email : %s - OTP Send Fail : %s" % (user_id, user_email, e))
        return "send_fail"



# pass_notice.py  notice_send_mail
def notice_send_mail():
    """
    User PassWord DeadLine Notice
    """
    with app.app_context():
        app.logger.info("Schedule Start")

        create_audit_log_for_scheduler()

        ldap_info = get_ldap_info()

        notice_info = db.session.query(Notice_info).first()
        mail_form = db.session.query(Mail_form).filter(Mail_form.type == "notice_mail").first()

        smtp = db.session.query(Smtp_info).first()

        app.config["MAIL_SERVER"] = smtp.mail_server
        app.config["MAIL_PORT"] = int(smtp.mail_port)

        if smtp.use_tls == "tls":
            app.config["MAIL_USE_TLS"] = True
            app.config["MAIL_USE_SSL"] = False

        elif smtp.use_tls == "ssl":
            app.config["MAIL_USE_TLS"] = False
            app.config["MAIL_USE_SSL"] = True

        else:
            app.config["MAIL_USE_TLS"] = False
            app.config["MAIL_USE_SSL"] = False

        if smtp.user_relay == "idpw":
            app.config["MAIL_USERNAME"] = smtp.mail_username
            app.config["MAIL_PASSWORD"] = smtp.mail_password

        app.config["MAIL_DEBUG"] = True

        ad_ip = ldap_info["ad_ip"]
        ad_domain = ldap_info["ad_domain"]
        admin_id = ldap_info["admin_id"]
        pw = ldap_info["admin_pw"]

        # ldaps_host = 'ldaps://%s:636' % ad_ip
        ldaps_host = "ldap://%s:389" % ad_ip
        admin = admin_id + "@" + ad_domain

        results = None

        try:
            ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_ALLOW)
            l = ldap.initialize(ldaps_host)
            l.set_option(ldap.OPT_REFERRALS, 0)
            l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
            l.simple_bind_s(admin, pw)

            base = notice_info.searchbase_ou
            criteria = "(&(objectClass=user))"
            # attributes = [
            #     "userPrincipalName",
            #     "msDS-UserPasswordExpiryTimeComputed",
            #     "cn",
            #     "mail",
            # ]
            attributes = [
                "userPrincipalName",
                "msDS-UserPasswordExpiryTimeComputed",
                "cn",
                "mail",
                "displayName",
                "employeeNumber"
            ]
            result = l.search_s(base, ldap.SCOPE_SUBTREE, criteria, attributes)

            results = [entry for dn, entry in result if isinstance(entry, dict)]

        except ldap.LDAPError as e:

            app.logger.info("Couldn't Connect. %s" % e)

        if results is not None:
            for data in results:
                if "userPrincipalName" in data.keys() and "mail" in data.keys():
                    try:
                        date = to_datetime(int(data["msDS-UserPasswordExpiryTimeComputed"][0].decode()))
                        time_remaining = (date - datetime.now()).days
                    except Exception as e:
                        app.logger.info(f'{data["cn"][0].decode()} 의 to_datetime 계산중 에러 발생')
                        app.logger.info(e)
                        time_remaining = 999

                    if int(time_remaining) <= notice_info.dead_line:

                        userPrincipalName = str(data["userPrincipalName"][0].decode())
                        cn = str(data["cn"][0].decode())

                        ad_user_mail = str(data["mail"][0].decode())

                        try:

                            sender_email = smtp.sender
                            user_email = ad_user_mail.split(",")

                            # list로 타입변경하여 다수에게도 전송 가능하도록.
                            # user_email = user_email.split(',')

                            if mail_form is None:
                                mail_title = "[한국은행] 외부망 Pass Changer - AD 비밀번호 만료 안내"
                                msg = Message(
                                    mail_title,
                                    sender=sender_email,
                                    recipients=user_email,
                                )

                                msg.attach(
                                    "passc_logo.png",
                                    "image/png",
                                    open("adpass/templates/images/passc_logo.png", "rb").read(),
                                    "inline",
                                    headers=[
                                        ["Content-ID", "<logo>"],
                                    ],
                                )
                                msg.html = render_template(
                                    "pass_notice.html",
                                    user_id=cn,
                                    day=time_remaining,
                                    upn=userPrincipalName,
                                    date=str(date).split(" ")[0],
                                )
                                logo = "adpass/templates/images/passc_logo.png"
                                base64_logo = image_to_base64_str(logo)
                                html = render_template(
                                    "pass_notice.html",
                                    user_id=cn,
                                    day=time_remaining,
                                    upn=userPrincipalName,
                                    date=str(date).split(" ")[0],
                                    logo=base64_logo
                                )

                            else:

                                mail_title = str(mail_form.subject_text)
                                msg = Message(
                                    mail_title,
                                    sender=sender_email,
                                    recipients=user_email,
                                )
                                if mail_form.logo is None:
                                    msg.attach(
                                        "passc_logo.png",
                                        "image/png",
                                        open(
                                            "adpass/templates/images/passc_logo.png",
                                            "rb",
                                        ).read(),
                                        "inline",
                                        headers=[
                                            ["Content-ID", "<logo>"],
                                        ],
                                    )
                                    logo = "adpass/templates/images/passc_logo.png"
                                    base64_logo = image_to_base64_str(logo)

                                else:
                                    msg.attach(
                                        "passc_logo.png",
                                        "image/png",
                                        open(
                                            "adpass/static/mail_logo/" + str(mail_form.logo),
                                            "rb",
                                        ).read(),
                                        "inline",
                                        headers=[
                                            ["Content-ID", "<logo>"],
                                        ],
                                    )
                                    logo = "adpass/static/mail_logo/" + str(mail_form.logo)
                                    base64_logo = image_to_base64_str(logo)

                                msg.html = render_template(
                                    "custom_pass_notice.html",
                                    user_id=cn,
                                    day=time_remaining,
                                    upn=userPrincipalName,
                                    date=str(date).split(" ")[0],
                                    button_color=str(mail_form.button_color),
                                    button_text_color=str(mail_form.button_text_color),
                                    logo_link=str(mail_form.logo_link).replace("\n", ""),
                                    explanation=str(mail_form.explanation).replace("\n", ""),
                                )

                                html = render_template(
                                    "custom_pass_notice.html",
                                    user_id=cn,
                                    day=time_remaining,
                                    upn=userPrincipalName,
                                    date=str(date).split(" ")[0],
                                    button_color=str(mail_form.button_color),
                                    button_text_color=str(mail_form.button_text_color),
                                    logo_link=str(mail_form.logo_link).replace("\n", ""),
                                    explanation=str(mail_form.explanation).replace("\n", ""),
                                    logo=base64_logo
                                )
                            app.logger.info(f"{data['cn'][0].decode()}")
                            # th = threading.Thread(target=send_email, args=(app, msg, cn))
                            # th.start()

                            recipient_info = {
                                'to_id': data['employeeNumber'][0].decode(),
                                'to_name': data['displayName'][0].decode(),
                                'to_email': data["mail"][0].decode()
                            }
                            insert_mail_data(html, recipient_info, mail_title)

                        except Exception as e:
                            app.logger.info("SMTP error  " + str(e))



# admin.py test_send_mail
@core_bp.route("/test_send_mail", methods=["POST"])
@check_admin_role
def test_send_mail():
    action = "Test Send Mail 버튼 클릭"
    description = "메일 전송 테스트"
    create_audit_log(action, description)

    current_app.logger.info("/test_send_mail")

    data = request.form
    error_word = ""

    app.config["MAIL_SERVER"] = data["mail_server"]
    app.config["MAIL_PORT"] = int(data["mail_port"])

    if data["use_tls"] == "tls":
        app.config["MAIL_USE_TLS"] = True
        app.config["MAIL_USE_SSL"] = False

    elif data["use_tls"] == "ssl":
        app.config["MAIL_USE_TLS"] = False
        app.config["MAIL_USE_SSL"] = True

    else:
        app.config["MAIL_USE_TLS"] = False
        app.config["MAIL_USE_SSL"] = False

    if data["use_relay"] == "idpw":
        app.config["MAIL_USERNAME"] = data["mail_id"]
        app.config["MAIL_PASSWORD"] = data["mail_pw"]
    app.config["MAIL_DEBUG"] = False
    try:
        mail_title = data["mail_title"]
        mail_content = data["mail_content"]
        sender_email = data["sender"]
        user_email = data["user_mail"]
        # list로 타입변경하여 다수에게도 전송 가능하도록.
        user_email = user_email.split(",")

        mail = Mail(app)
    except Exception as e:
        current_app.logger.info("smtp error : %s" % e)
        error_word = str(e)
    try:
        # msg = Message(mail_title, sender=sender_email, recipients=user_email)
        # msg.body = mail_content
        # mail.send(msg)
        '''
        외부망
        '''
        recipient_info = get_recipient_info(user_email)
        html = f"<p>{mail_content}</p>"
        insert_mail_data(html, recipient_info, mail_title)
    except Exception as e:
        current_app.logger.info("test_send_mail error : %s" % e)
        error_word = str(e)
    return jsonify(error_word)