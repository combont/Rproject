'''
내부망 Sync Manager
'''

# settings.py
FTP_IP = "172.16.100.65"
FTP_PORT = 22
FTP_ID = "cozy"
FTP_PW = "coraise123!"
FTP_TYPE = "ssl"
FTP_TYPE = None
FTP_SENDER = "SENDER_EMP_CODE=sync_manager@coraise.co.kr \n"
FTP_SUBJECT = "SUBJECT=[한국은행] 외부망 AD Sync Report \n"


# lib.py make_mail_file
def make_mail_file(html, employee_number, subject, sender_email):
    # FTP 전송할 파일 만들기
    try:
        app.logger.info("[ Making FTP Mail File Start ]")
        random_int = random.randint(1, 99999)
        today = datetime.today().strftime("%Y%m%d%H%M_%H%M")
        today2 = datetime.today().strftime("%Y%m%d%H%M")

        file1_name = f"2_{today}{random_int}"
        file2_name = file1_name
        file3_name = f"0{today}{random_int}"

        file1_path = "/Users/cozy/Desktop/ftp_test"
        file2_path = "/Users/cozy/Desktop/ftp_test/snap"
        file3_path = "/Users/cozy/Desktop/ftp_test"

        f1 = open(f'{file1_path}/{file1_name}.msg', 'w')
        
        receiver = f"TO_EMP_CODE={employee_number} \n"
        
        content1 = [
            "APP=1 \n",
            f"SENDER_EMP_CODE={sender_email} \n",
            "COMMUNITY_ID=001000000 \n",
            f"SUBJECT={subject} \n",
            f"SEND_DATE={today2} \n",
            f"BODY_PHY_FILE_NAME={file3_name}\n",
            "ATT_CNT=0 \n",
            receiver,
        ]
        f1.writelines(content1)
        f1.close()

        f2 = open(f'{file2_path}/{file2_name}', 'w')
        content2 = [
            f"{file1_name} \n",
            f"{file3_name} \n",
        ]
        f2.writelines(content2)
        f2.close()


        f3 = open(f'{file3_path}/{file3_name}', 'w')
        content3 = html
        f3.write(content3)
        f3.close()
        app.logger.info("[ Making FTP Mail File End ]")
    except Exception as e:
        app.logger.info("Making FTP Mail File Error : %s" % e)


    # app.logger.info("File Upload Start")

    ftp_type = settings.FTP_TYPE

    file_info = {
        'file1_name': file1_name,
        'file2_name': file2_name,
        'file3_name': file3_name,
        'file1_path': file1_path,
        'file2_path': file2_path,
        'file3_path': file3_path
    }
    return file_info, ftp_type



# mail.send 있는 곳 (send_mail, error_send_mail, test_send_mail)
connection = sftp_connect()
for employee_number in user_email:
    file_info, ftp_type = make_mail_file(msg.html, employee_number, subject, sender_email)
    upload_file_sftp(connection, file_info)
connection.close()