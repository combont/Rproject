@core_bp.route("/change_user_pw", methods=["POST"])
@login_required
def change_user_pw():
    data = request.json

    targets = [data["sAMAccountName"]]
    action = "사용자 비밀번호 변경"
    description = f"대상 : {targets}"
    create_audit_log(action, description)

    l = ad_connect()[0]

    dn = data["dn"]
    cn = make_cn(dn)
    new_pw = '"{0}"'.format(data["new_pw"]).encode("utf-16-le")
    try:
        l.modify_s(dn, [(ldap.MOD_REPLACE, "unicodePwd", new_pw)])

        content = f"{cn} 비밀번호 변경"
        add_log("user", "updated", content)
        current_app.logger.info(f"User ({data['sAMAccountName']}) 비밀번호 변경")

        return make_response(
            jsonify(
                {
                    "message": "success",
                }
            ),
            200,
        )

    except ldap.LDAPError as e:
        content = f"{cn} 비밀번호 변경 실패"
        add_log("user", "fail", content)
        current_app.logger.info(f"{ldap_error_code(e)} / {dn} 비밀번호 변경 실패")

        return make_response(
            jsonify(
                {
                    "message": "fail",
                }
            ),
            500,
        )


# 관리자 권한 부여 & 해제 할 때 UAC 값 변경

# 권한 부여할 때 admin/viewer
if object == "user":
    # 사용자의 userAccountControl 속성값 66048 로 변경
    l.modify_s(dn, [(ldap.MOD_REPLACE, "userAccountControl", "66048".encode())])

# 권한 부여할 때 admin/viewer
if object == "user":
    # 사용자의 userAccountControl 속성값 544 로 변경
    l.modify_s(dn, [(ldap.MOD_REPLACE, "userAccountControl", "544".encode())])