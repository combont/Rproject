'''
외부망 Sync Manager
'''

# settings.py
MAIL_HOST = "172.16.100.53"
MAIL_PORT = "1521"
MAIL_SID = "orcl"
MAIL_USER = "c##coraise"
MAIL_PW = "dev123"
MAIL_TABLE = "BOK_MAIL"
MAIL_SOLUTION_EMP_NO = "SyncM"
MAIL_SOLUTION_NAME = "코레이즈 홀딩스"
MAIL_SOLUTION_EMAIL = "dev@coraise.co.kr"



# lib.py
def insert_mail_data(html, recipient_info, subject, sender_email):
    app.logger.info("Mail DB Start")
    error_word = ""

    host = settings.MAIL_HOST
    port = settings.MAIL_PORT
    sid = settings.MAIL_SID
    user = settings.MAIL_USER
    password = settings.MAIL_PW
    table_name = settings.MAIL_TABLE
    try:
        dsn = cx.makedsn(host, port, sid)
        result = cx.connect(user, password, dsn)

    except Exception as e:
        app.logger.info(e)
        error_word = str(e)

        if "ORA-12170" in error_word:
            error_word = "timed out"
        elif "ORA-12545" in error_word:
            error_word = "connect fail"
        elif "ORA-12505" in error_word:
            error_word = "sid"
        elif "ORA-01017" in error_word:
            error_word = "id/pw"
        
        app.logger.info(error_word)

    insert_query = f"INSERT INTO {table_name} (SEQ, MSG_CODE, TO_ID, TO_NAME, TO_EMAIL, FROM_NAME, FROM_EMAIL, TARGET_DATE, REG_DATE, SUBJECT, MAP_CONTENT) VALUES (my_seq.nextval, :1, :2, :3, :4, :5, :6, :7, :8, :9, :10)"

    sysdate = datetime.now()
    to_id = f"{recipient_info['to_id']}{settings.MAIL_SOLUTION_EMP_NO}"
    to_name = f"{recipient_info['to_name']}{settings.MAIL_SOLUTION_NAME}"
    to_email = f"{recipient_info['to_email']}{settings.MAIL_SOLUTION_EMAIL}"
    subject = subject

    try:
        cur = result.cursor()
        cur.execute(insert_query, ['AD01', to_id, to_name, to_email, 'AD시스템', sender_email, sysdate, sysdate, subject, html])
        result.commit()

        cur.close()
        result.close()

    except Exception as e:
        app.logger.info(e)

    app.logger.info("Mail DB End")



# ldap_lib.py
def get_recipient_info(users):
    l, base = ad_connect()

    recipient_info = {
        "to_id": "",
        "to_name": "",
        "to_email": "",
    }

    attributes = ["mail", "displayName", "employeeNumber"]
    for employee_number in users:
        criteria = f"(&(objectClass=user)(employeeNumber={employee_number}))"
        result = ldap_search(l, base, criteria, attributes)

        if result:
            result = result[0]
            for k, v in result.items():
                if k == 'displayName':
                    recipient_info['to_name'] += f"{v[0].decode()};"
                elif k == 'employeeNumber':
                    recipient_info['to_id'] += f"{v[0].decode()};"
                else:
                    recipient_info['to_email'] += f"{v[0].decode()};"
    
    return recipient_info



# mail.send 있는 곳 (send_mail, error_send_mail, test_send_mail)
recipient_info = get_recipient_info(user_email)
insert_mail_data(msg.html, recipient_info, mail_title, sender_email)