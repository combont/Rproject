$(document).on("click", "#user_change_pw", function () {
    var table = Tabulator.findTable("#user_table")[0];
    if (!table) {
        return;
    }

    var tabledata = table.getSelectedData();
    if (tabledata.length == 0) {
        return;
    } else if (tabledata.length > 1) {
        Swal.fire({
            text: "한 명의 사용자만 선택해주세요.",
            icon: "warning",
            confirmButtonColor: "#3759d7",
        });
        return true;
    }

    $("#pw_change_smn").val(tabledata[0]["sAMAccountName"]);
    $("#pw_change_dn").val(tabledata[0]["dn"]);
    make_modal_popup($("#pw_change_popup"));
});

$(document).on("click", "#pw_change_button", function () {
    var data = new FormData();

    data["sAMAccountName"] = $("#pw_change_smn").val();
    data["dn"] = $("#pw_change_dn").val();

    var new_pw = $("#new_pw").val();
    if (new_pw == "") {
        Swal.fire({
            text: "새 비밀번호를 입력해주세요.",
            icon: "warning",
            confirmButtonColor: "#3759d7",
        });
        return true;
    }
    data["new_pw"] = new_pw;

    var json_data = JSON.stringify(data);
    var url = "/change_user_pw";

    $._ajax({
        url: url,
        data: json_data,
        contentType: "application/json",
        type: "POST",
        success: function (result) {
            Swal.fire({
                title: "성공",
                icon: "success",
                confirmButtonColor: "#3759d7",
            });
            $("#modal_bg2").click();
        },
        error: function (result) {
            Swal.fire({
                title: "DB 저장중 에러발생",
                icon: "error",
                confirmButtonColor: "#3759d7",
            });
        },
    });
});
